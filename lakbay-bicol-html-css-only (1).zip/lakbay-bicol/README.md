# Lakbay Bicol

A creative Travel and Tourism website concept promoting destinations and travel experiences in the Bicol Region of the Philippines.

## Pages
- `index.html` — Home page and featured destinations
- `about.html` — About Lakbay Bicol and the Bicol experience
- `gallery.html` — Visual travel gallery
- `css/style.css` — Complete responsive styling

## Technologies
- HTML5
- CSS3

## Important
This project intentionally uses **HTML5 and CSS3 only**. No JavaScript, JavaScript libraries, or frameworks are used.

## GitHub Pages
1. Create a public GitHub repository.
2. Upload the entire `lakbay-bicol` folder contents.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Choose the `main` branch and `/ (root)`.
6. Save and open the generated GitHub Pages URL.

## Image sources
The project includes local image placeholder files in the `images` folder. Replace them with your own properly licensed tourism photographs before publishing.

© 2026 Lakbay Bicol
